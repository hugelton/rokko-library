// Web Audio API & WASM 管理
class KomyoSynth {
    constructor() {
        this.audioContext = null;
        this.wasmModule = null;
        this.scriptProcessor = null;
        this.isPlaying = false;
        this.currentNote = 48; // C3
        this.octaveShift = 0;
        this.sampleRate = 48000;
        this.mandalaTime = 0;
        this.frontImageIndex = 0;
        this.vibratoSpeed = 5.5;
        this.vibratoDepth = 50;
        this.vibratoDelay = 100; // ms
        this.formantPortamentoMs = 0;
        this.pitchPortamentoMs = 0;
        this.targetNote = 48;
        this.currentPitch = 48;
        this.randomFormant = false;
        this.currentVowel = 0; // 初期値はア（WASMと同期）

        // 瞬き関連
        this.noteOnStartTime = null; // ノートオン開始時間
        this.blinkTimer = null; // アイドル時の瞬きタイマー
        this.wideEyesTimer = null; // 目をカッ開くタイマー
        this.isIdleBlinking = false; // アイドル瞬き中か
        this.noteIsActive = false; // ノートオン中か
        this.backgroundMode = 'black'; // 背景モード（green, black）
        this.mandalaAnimationActive = false; // 曼荼羅アニメーション中か
        this.waveDistortion = null; // Wave Distortionエンジン
    }

    // msから補間速度に変換（99%到達時間）
    msToInterpolationSpeed(ms) {
        if (ms <= 0) return 1.0; // 0の時は即座に変更（ポルタメントオフ）
        // msミリ秒で99%到達するための1サンプルあたりの補間係数
        const samples = ms * this.sampleRate / 1000;
        // 0.01 = 1% (99%減衰)
        // 1サンプルあとの係数 r として r^samples = 0.01
        // よって r = 0.01^(1/samples)
        return 1.0 - Math.pow(0.01, 1.0 / samples);
    }

    async init() {
        try {
            // Web Audio APIの初期化
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)({
                sampleRate: 48000,
                latencyHint: 'interactive' // 低遅延モード
            });

            // WASM モジュールをロード（EmscriptenのJSグルーコードを使用）
            this.wasmModule = await KomyoWasm();

                // WASMの初期化関数を呼び出し（新しいエンジンでは不要）
            if (typeof this.wasmModule.__init === 'function') {
                this.wasmModule.__init();
            }

            // ドライブ量を 0.8 に設定（デフォルト値）
            if (typeof this.wasmModule.__setDrive === 'function') {
                this.wasmModule.__setDrive(0.8);
            }

            // Canvasは既にcreateInitialCanvas()で作成済み
            // アニメーションループはstart()で開始

            return true;
        } catch (error) {
            console.error('初期化エラー:', error);
            throw error;
        }
    }

    start() {
        if (this.isPlaying) return;

        // AudioContextをサスペンド状態から復帰
        if (this.audioContext.state === 'suspended') {
            this.audioContext.resume();
        }

        // デバッグ: レイテンシー情報をコンソールに出力
        console.log('AudioContext state:', this.audioContext.state);
        console.log('Base latency:', this.audioContext.baseLatency, 'seconds');
        console.log('Output latency:', this.audioContext.outputLatency, 'seconds');

        const bufferSize = 2048; // 元の設定（約42.7ms @ 48kHz）
        this.scriptProcessor = this.audioContext.createScriptProcessor(bufferSize, 1, 1);

        this.scriptProcessor.onaudioprocess = (event) => {
            const outputBuffer = event.outputBuffer.getChannelData(0);

            for (let i = 0; i < outputBuffer.length; i++) {
                outputBuffer[i] = this.wasmModule.__process();
            }
        };

        this.scriptProcessor.connect(this.audioContext.destination);
        this.isPlaying = true;

        // sleeping状態を解除（WaveDistortionが'a.png'をプリロード済み）
        if (this.waveDistortion) {
            this.waveDistortion.showingSleeping = false;
        }

        // アイドル瞬き開始
        this.startIdleBlinking();

        // アニメーションループを開始
        this.startAnimationLoop();
    }

    stop() {
        if (!this.isPlaying) return;

        this.scriptProcessor.disconnect();
        this.scriptProcessor = null;
        this.isPlaying = false;

        // 曼荼羅アニメーション停止
        this.stopMandalaAnimation();

        // アイドル瞬き停止
        this.stopIdleBlinking();

        // 目エフェクト全てクリア
        this.hideEyes();
        if (this.wideEyesTimer) {
            clearTimeout(this.wideEyesTimer);
            this.wideEyesTimer = null;
        }
    }

    startMandalaAnimation() {
        const canvas = document.getElementById('mandalaCanvas');
        if (!canvas) return;

        this.mandalaAnimationActive = true;

        // 初期状態は黒背景
        this.drawBlackBackground(canvas);

        const ctx = canvas.getContext('2d');

        // Set canvas to actual image size (1024x837)
        canvas.width = 1024;
        canvas.height = 837;

        const animate = () => {
            if (!this.isPlaying) return;

            const width = canvas.width;
            const height = canvas.height;
            const centerX = width / 2;
            const centerY = height / 2;
            const maxRadius = Math.sqrt(centerX * centerX + centerY * centerY);

            // 暗い背景でクリア
            ctx.fillStyle = '#000';
            ctx.fillRect(0, 0, width, height);

            // パラメータに基づいて色や速度を調整
            const pitchFactor = this.currentPitch / 48.0; // ピッチによるスケール
            const speedFactor = this.vibratoSpeed / 5.5; // LFO速度によるスケール
            const depthFactor = this.vibratoDepth / 50.0; // LFO深度によるスケール

            const time = this.mandalaTime * 0.0005 * speedFactor;

            // 暗めのオレンジと黄色（深度で明るさ調整）
            const orange1 = `rgba(255, 123, 0, ${0.10 + depthFactor * 0.08})`;
            const orange2 = `rgba(255, 100, 0, ${0.08 + depthFactor * 0.06})`;
            const yellow1 = `rgba(255, 200, 0, ${0.08 + depthFactor * 0.07})`;
            const yellow2 = `rgba(200, 150, 0, ${0.06 + depthFactor * 0.05})`;

            // 8回対称の万華鏡パターン（ピッチで対称数を変化）
            const numSymmetries = Math.floor(6 + pitchFactor * 4);
            const baseRotation = time * 0.1;

            for (let symmetry = 0; symmetry < numSymmetries; symmetry++) {
                const baseAngle = (symmetry / numSymmetries) * Math.PI * 2 + baseRotation;

                // 複数の層を描画（ピッチで層数を変化）
                const numLayers = Math.floor(4 + pitchFactor * 3);
                for (let layer = 0; layer < numLayers; layer++) {
                    const layerRadius = (layer + 1) * (maxRadius / (numLayers + 2)) * pitchFactor;
                    const layerOffset = Math.sin(time + layer * 0.5) * Math.min(20, layerRadius * 0.3) * depthFactor;

                    // 放射線
                    ctx.beginPath();
                    ctx.strokeStyle = layer % 2 === 0 ? orange1 : yellow1;
                    ctx.lineWidth = 1;
                    ctx.moveTo(centerX, centerY);
                    const endX = centerX + Math.cos(baseAngle + time * 0.2) * (layerRadius + layerOffset);
                    const endY = centerY + Math.sin(baseAngle + time * 0.2) * (layerRadius + layerOffset);
                    ctx.lineTo(endX, endY);
                    ctx.stroke();

                    // 円弧
                    ctx.beginPath();
                    ctx.strokeStyle = layer % 3 === 0 ? orange2 : yellow2;
                    ctx.lineWidth = 1.5;
                    ctx.arc(centerX, centerY, Math.max(0, layerRadius + layerOffset),
                            baseAngle + time * 0.3, baseAngle + Math.PI / 4 + time * 0.3);
                    ctx.stroke();

                    // 装飾的な円
                    if (layer % 2 === 0) {
                        const decorX = centerX + Math.cos(baseAngle * 2 + time * 0.15) * layerRadius;
                        const decorY = centerY + Math.sin(baseAngle * 2 + time * 0.15) * layerRadius;
                        ctx.beginPath();
                        ctx.strokeStyle = orange1;
                        ctx.lineWidth = 1;
                        const decorSize = (10 + Math.sin(time * 2 + layer) * 3) * depthFactor;
                        ctx.arc(decorX, decorY, Math.max(0, decorSize), 0, Math.PI * 2);
                        ctx.stroke();
                    }
                }
            }

            // 中心の曼荼羅パターン（深度でリング数を変化）
            const numRings = Math.floor(3 + depthFactor * 2);
            for (let ring = 0; ring < numRings; ring++) {
                const ringRadius = (30 + ring * 25) * pitchFactor;
                const numPetals = Math.floor(6 + ring * 2 + speedFactor * 2);

                for (let petal = 0; petal < numPetals; petal++) {
                    const angle = (petal / numPetals) * Math.PI * 2 + time * 0.2 * (ring % 2 === 0 ? 1 : -1);
                    const x = centerX + Math.cos(angle) * ringRadius;
                    const y = centerY + Math.sin(angle) * ringRadius;

                    ctx.beginPath();
                    ctx.fillStyle = ring % 2 === 0 ? orange1 : yellow1;
                    const petalSize = (8 + Math.sin(time * 3 + petal) * 3) * depthFactor;
                    ctx.arc(x, y, Math.max(0, petalSize), 0, Math.PI * 2);
                    ctx.fill();
                }
            }

            this.mandalaTime += 16;
            requestAnimationFrame(animate);
        };

        animate();
    }

    stopMandalaAnimation() {
        this.mandalaAnimationActive = false;
    }

    setBackgroundMode(mode) {
        this.backgroundMode = mode;
        console.log('Background mode changed to:', mode);
        // Background will be drawn in next animation frame
    }

    drawGreenBackground(canvas) {
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;

        // 緑背景を描画
        ctx.fillStyle = '#00ff00';
        ctx.fillRect(0, 0, width, height);
    }

    drawBlackBackground(canvas) {
        const ctx = canvas.getContext('2d');
        const width = canvas.width;
        const height = canvas.height;

        // 黒背景を描画
        ctx.fillStyle = '#000000';
        ctx.fillRect(0, 0, width, height);
    }

    createInitialCanvas() {
        // 既存のDOM画像を非表示にする
        const faceImageFront = document.getElementById('faceImageFront');
        const faceImageBack = document.getElementById('faceImageBack');
        const faceImageBase = document.getElementById('faceImageBase');
        const eyeOverlay = document.getElementById('eyeOverlay');

        if (faceImageFront) faceImageFront.style.display = 'none';
        if (faceImageBack) faceImageBack.style.display = 'none';
        if (faceImageBase) faceImageBase.style.display = 'none';
        if (eyeOverlay) eyeOverlay.style.display = 'none';

        // 画像用のCanvasを作成
        const visualizerDiv = document.querySelector('.visualizer');
        if (!visualizerDiv) return;

        // 既存のCanvasがあれば削除
        const existingCanvas = document.getElementById('waveDistortionCanvas');
        if (existingCanvas) {
            existingCanvas.remove();
        }

        const canvas = document.createElement('canvas');
        canvas.id = 'waveDistortionCanvas';
        canvas.style.position = 'absolute';
        canvas.style.top = '0';
        canvas.style.left = '0';
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.zIndex = '3';

        visualizerDiv.appendChild(canvas);

        // Wave Distortionエンジンを初期化（まだアニメーションは開始しない）
        this.waveDistortion = new WaveDistortion(canvas);

        // sleeping.pngを描画（画像がロードされるのを待つ）
        const tryDrawSleeping = () => {
            if (this.waveDistortion && this.waveDistortion.sleepingImage) {
                if (this.waveDistortion.sleepingImage.complete) {
                    // 画像がロードされたら描画
                    this.waveDistortion.drawSleepingImage();
                } else {
                    // まだロードされていない場合はonloadを設定
                    this.waveDistortion.sleepingImage.onload = () => {
                        this.waveDistortion.drawSleepingImage();
                    };
                }
            }
        };

        // 画像がまだ完全にロードされていない場合は待つ
        if (this.waveDistortion.sleepingImage.complete) {
            tryDrawSleeping();
        } else {
            this.waveDistortion.sleepingImage.onload = tryDrawSleeping;
        }
    }

    startAnimationLoop() {
        // 目エフェクト用
        this.currentEyeOpacity = 0;

        const animate = () => {
            if (!this.isPlaying) return;

            if (this.waveDistortion) {
                // sleeping状態の場合はsleeping.pngを描画
                if (this.waveDistortion.showingSleeping) {
                    this.waveDistortion.drawSleepingImage();
                } else {
                    // LFO時間を計算（vibratoSpeedと同期）
                    const lfoTime = this.mandalaTime * 0.001 * this.vibratoSpeed;

                    // 振幅を計算（vibratoDepthに応じて、最大7.5）
                    const maxAmplitude = 7.5;
                    const baseAmplitude = maxAmplitude * (this.vibratoDepth / 200.0); // 0-200 → 0-7.5

                    // vibratoDelayを考慮して振幅を調整
                    let amplitude = baseAmplitude;
                    if (this.noteIsActive && this.noteOnStartTime) {
                        const timeSinceNoteOn = Date.now() - this.noteOnStartTime;
                        const delayMs = this.vibratoDelay;

                        if (timeSinceNoteOn < delayMs) {
                            // vibratoDelay期間中は振幅を0にする
                            amplitude = 0;
                        } else {
                            // delay経過後は指数関数的に振幅を増加させる
                            const timeAfterDelay = timeSinceNoteOn - delayMs;
                            const attackTime = 500; // 500msで最大振幅に到達
                            const attackFactor = Math.min(1.0, timeAfterDelay / attackTime);
                            amplitude = baseAmplitude * (1.0 - Math.exp(-3.0 * attackFactor));
                        }
                    } else if (!this.noteIsActive) {
                        // ノートオフ時は振幅を0にする
                        amplitude = 0;
                    }

                    // 全てのレイヤーをCanvas内で描画
                    const faceImageBase = document.getElementById('faceImageBase');
                    const faceImageFront = document.getElementById('faceImageFront');
                    const eyeOverlay = document.getElementById('eyeOverlay');

                    // 画像が読み込まれているかチェック
                    const baseImageLoaded = faceImageBase && faceImageBase.naturalWidth > 0;
                    const frontImageLoaded = faceImageFront && faceImageFront.naturalWidth > 0;

                    if (baseImageLoaded && frontImageLoaded) {
                        // 目エフェクトの透明度を取得
                        const eyeOverlayElement = document.getElementById('eyeOverlay');
                        const eyeOpacity = eyeOverlayElement ? parseFloat(eyeOverlayElement.style.opacity || 0) : 0;

                        if (this.noteIsActive) {
                            // ノートオン時：Wave Distortionを適用（LFO同期、Depth連動、Delay考慮）
                            this.waveDistortion.drawLayersWithDistortion(
                                faceImageBase,
                                faceImageFront,
                                eyeOverlay,
                                eyeOpacity,
                                lfoTime,
                                amplitude
                            );
                        } else {
                            // ノートオフ時：Wave Distortionなしで描画（「ン」の画像を使用）
                            this.waveDistortion.drawLayers(
                                faceImageBase,
                                faceImageFront,
                                eyeOverlay,
                                eyeOpacity
                            );
                        }
                    } else {
                        // 画像がまだロードされていない場合はプリロード画像を使用
                        if (this.waveDistortion && this.waveDistortion.vowelImages && this.waveDistortion.vowelImages['a']) {
                            const vowelA = this.waveDistortion.vowelImages['a'];
                            if (vowelA.complete) {
                                if (this.noteIsActive) {
                                    this.waveDistortion.drawLayersWithDistortion(
                                        vowelA,
                                        vowelA,
                                        null,
                                        0,
                                        lfoTime,
                                        amplitude
                                    );
                                } else {
                                    this.waveDistortion.drawLayers(
                                        vowelA,
                                        vowelA,
                                        null,
                                        0
                                    );
                                }
                            }
                        }
                    }
                }
            }

            this.mandalaTime += 16;
            requestAnimationFrame(animate);
        };

        // アニメーション開始（isPlayingがtrueになったら描画が開始される）
        animate();
    }

    setPortamento(value) {
        if (this.wasmModule) {
            this.wasmModule.__setPortamento(value);
        }
    }

    setFormantPortamentoMs(ms) {
        this.formantPortamentoMs = ms;
    }

    setFormantOffset(value) {
        if (this.wasmModule) {
            this.wasmModule.__setFormantOffset(value);
        }
    }

    setPitchOffset(value) {
        if (this.wasmModule) {
            this.wasmModule.__setPitchOffset(value);
        }
    }

    setMasterVolume(value) {
        if (this.wasmModule) {
            this.wasmModule.__setMasterVolume(value);
        }
    }

    setQ(value) {
        if (this.wasmModule) {
            this.wasmModule.__setQ(value);
        }
    }

    setDrive(value) {
        if (this.wasmModule) {
            this.wasmModule.__setDrive(value);
        }
    }

    noteOn(midiNote) {
        this.currentNote = midiNote;
        this.targetNote = midiNote;
        this.currentFrequency = 440.0 * Math.pow(2.0, (midiNote - 69) / 12.0);
        this.noteIsActive = true;

        // ノートオン開始時間を記録
        this.noteOnStartTime = Date.now();

        if (this.wasmModule) {
            this.wasmModule.__noteOn(midiNote);

            // ランダムフォルマントがONならランダムな母音を選択
            if (this.randomFormant) {
                const randomVowel = Math.floor(Math.random() * 11); // 0-10 (11フォルマント)
                this.setVowel(randomVowel);
            } else {
                // ランダムフォルマントがOFFなら、現在の母音で画像を再設定
                this.setFaceImage(this.currentVowel);
            }
        }

        // アイドル瞬きを停止
        this.stopIdleBlinking();

        // 5秒後に目をカッ開く
        if (this.wideEyesTimer) {
            clearTimeout(this.wideEyesTimer);
        }
        this.wideEyesTimer = setTimeout(() => {
            this.showEyes('open');
        }, 5000);
    }

    noteOff() {
        this.noteIsActive = false;

        if (this.wasmModule) {
            this.wasmModule.__noteOff();
        }

        // 音が止まったら顔画像だけ「ン」に戻す（フォルマントは維持）
        this.setFaceImage(5); // 5 = N (ン)

        // 目エフェクト非表示
        this.hideEyes();
        if (this.wideEyesTimer) {
            clearTimeout(this.wideEyesTimer);
            this.wideEyesTimer = null;
        }

        // アイドル瞬き再開
        this.startIdleBlinking();
    }

    setRandomFormant(enabled) {
        this.randomFormant = enabled;
    }

    setFormant(vowelIndex) {
        console.log('setFormant called with index:', vowelIndex);
        this.currentVowel = vowelIndex;
        if (this.wasmModule) {
            this.wasmModule.__setVowel(vowelIndex);
            console.log('WASM _setVowel called');
        }
    }

    setFaceImage(vowelIndex) {
        // 画像切り替え（ディゾルブ）
        const faceImageFront = document.getElementById('faceImageFront');
        const faceImageBack = document.getElementById('faceImageBack');
        const faceImageBase = document.getElementById('faceImageBase');

        if (faceImageFront && faceImageBack && faceImageBase) {
            const newSrc = vowelImages[vowelIndex];

            // 全ての画像を即座に更新（ディゾルブ効果なし）
            faceImageBase.src = newSrc;
            faceImageFront.src = newSrc;
            faceImageBack.src = newSrc;

            // 画像が読み込まれるのを待つ
            faceImageBase.onload = () => {
                faceImageFront.onload = () => {
                    faceImageBack.onload = () => {
                        // 全て読み込まれたら完了
                    };
                };
            };
        }
    }

    setVowel(vowelIndex) {
        // フォルマントと画像の両方を変更（今まで通りの動作）
        this.setFormant(vowelIndex);
        this.setFaceImage(vowelIndex);
    }

    setPitchPortamento(value) {
        if (this.wasmModule) {
            this.wasmModule.__setPitchPortamento(value);
        }
    }

    setPitchPortamentoMs(ms) {
        this.pitchPortamentoMs = ms;
    }

    setVibratoDepth(value) {
        if (this.wasmModule) {
            this.wasmModule.__setVibratoDepth(value);
            this.vibratoDepth = value;
        }
    }

    setVibratoSpeed(value) {
        if (this.wasmModule) {
            this.wasmModule.__setVibratoSpeed(value);
            this.vibratoSpeed = value;
        }
    }

    setVibratoDelay(value) {
        if (this.wasmModule) {
            this.wasmModule.__setVibratoDelay(value);
        }
        this.vibratoDelay = value;
    }

    // アイドル時の瞬き開始
    startIdleBlinking() {
        if (this.isIdleBlinking) return;
        this.isIdleBlinking = true;
        this.scheduleNextBlink();
    }

    // アイドル時の瞬き停止
    stopIdleBlinking() {
        this.isIdleBlinking = false;
        if (this.blinkTimer) {
            clearTimeout(this.blinkTimer);
            this.blinkTimer = null;
        }
    }

    // 次の瞬きをスケジュール（人間の瞬きタイミング: 2-8秒ごと）
    scheduleNextBlink() {
        if (!this.isIdleBlinking) return;

        // 人間の瞬きタイミング: 2-8秒のランダム
        const nextBlinkTime = 2000 + Math.random() * 6000;

        this.blinkTimer = setTimeout(() => {
            this.showEyes('close');
            // 150-250ms後に目を開ける
            setTimeout(() => {
                this.hideEyes();
            }, 150 + Math.random() * 100);

            // 次の瞬きをスケジュール
            this.scheduleNextBlink();
        }, nextBlinkTime);
    }

    // 目エフェクト表示
    showEyes(type) {
        const eyeOverlay = document.getElementById('eyeOverlay');
        if (!eyeOverlay) return;

        if (type === 'close') {
            eyeOverlay.src = 'eye_close_a_mask.png';
        } else if (type === 'open') {
            eyeOverlay.src = 'eye_open_a_mask.png';
        }

        eyeOverlay.style.opacity = '1';
    }

    // 目エフェクト非表示
    hideEyes() {
        const eyeOverlay = document.getElementById('eyeOverlay');
        if (eyeOverlay) {
            eyeOverlay.style.opacity = '0';
        }
    }
}

// 仮想音名マップ
const keyboardMap = {
    // 新しいキーボード配置: awsedftgyhujkolp;' のクロマチック順
    // ベースノートは C3=48 から開始
    'a': 48,  // C3
    'w': 49,  // C#3
    's': 50,  // D3
    'e': 51,  // D#3
    'd': 52,  // E3
    'f': 53,  // F3
    't': 54,  // F#3
    'g': 55,  // G3
    'y': 56,  // G#3
    'h': 57,  // A3
    'u': 58,  // A#3
    'j': 59,  // B3
    'k': 60,  // C4
    'o': 61,  // C#4
    'l': 62,  // D4
    'p': 63,  // D#4
    ';': 64,  // E4
    "'": 65   // F4
};

// 母音マップ（11個全てに対応）
const vowelMap = {
    '1': 0,  // A (ア)
    '2': 1,  // I (イ)
    '3': 2,  // U (ウ)
    '4': 3,  // E (エ)
    '5': 4,  // O (オ)
    '6': 5,  // M (ン)
    '7': 6,  // N (ン)
    '8': 7,  // AE (アエ)
    '9': 8,  // Y (ユ)
    '0': 9,  // R (ル)
    '-': 10  // W (ウ)
};

const vowelNames = ['A', 'I', 'U', 'E', 'O', 'M', 'N', 'AE', 'Y', 'R', 'W'];
const vowelImages = ['a.png', 'i.png', 'u.png', 'ye.png', 'o.png', 'm.png', 'n.png', 'ae.png', 'y.png', 'r.png', 'w.png'];

// アプリケーション
class App {
    constructor() {
        this.synth = new KomyoSynth();
        this.activeNotes = new Map(); // 押されているノートを追跡
        this.setupUI();
        this.setupKeyboard();

        // MIDIサポートを追加
        if (navigator.requestMIDIAccess) {
            this.midiHandler = new MidiInputHandler(this.synth);
        }
    }

    setupUI() {
        const startButton = document.getElementById('startButton');
        const headerInfoButton = document.getElementById('headerInfoButton');
        const app = document.getElementById('app');

        // 初期状態でappを表示
        app.classList.remove('hidden');

        // Audio/MIDIステータスの初期表示
        this.updateAudioStatus(false);
        this.updateMidiStatus();

        // 起動時にCanvasを作成してsleeping.pngを表示
        this.synth.createInitialCanvas();

        // Infoボタンのセットアップ
        if (headerInfoButton) {
            headerInfoButton.addEventListener('click', () => {
                const infoModal = document.getElementById('infoModal');
                if (infoModal) {
                    infoModal.classList.add('active');
                }
            });
        }

        // Info modal setup (close button, outside click, escape key)
        this.setupInfoModal();

        startButton.addEventListener('click', async () => {
            startButton.disabled = true;

            try {
                await this.synth.init();
                this.setupControls();
                this.setupBackgroundSelector();
                this.setupVirtualKeyboard();

                // Audioステータスを更新
                this.updateAudioStatus(true);

                this.synth.start();

                // visualizerのopacityをリセット
                const visualizer = document.querySelector('.visualizer');
                if (visualizer) {
                    visualizer.style.opacity = '1';
                    visualizer.style.pointerEvents = 'auto';
                }

                // コントロールのdisabledを解除
                const leftColumn = document.getElementById('leftColumn');
                const controls = document.getElementById('controls');
                const keyboardUI = document.getElementById('keyboardUI');
                const disabledOverlay = document.getElementById('disabledOverlay');
                if (leftColumn) leftColumn.classList.remove('disabled');
                if (controls) controls.classList.remove('disabled');
                if (keyboardUI) keyboardUI.classList.remove('disabled');
                if (disabledOverlay) disabledOverlay.classList.add('hidden');

                // Startボタンのテキストを変更
                startButton.textContent = 'Running';
            } catch (error) {
                console.error('Error:', error);
                startButton.disabled = false;
                startButton.textContent = 'リトライ';
                this.updateAudioStatus(false);
            }
        });
    }

    updateAudioStatus(isActive) {
        const audioStatus = document.getElementById('audioStatus');
        if (!audioStatus) return;

        const indicator = audioStatus.querySelector('.status-indicator');
        const value = audioStatus.querySelector('.status-value');

        if (isActive) {
            if (indicator) indicator.classList.add('active');
            if (value) value.textContent = 'Running';
        } else {
            if (indicator) indicator.classList.remove('active');
            if (value) value.textContent = 'Ready';
        }
    }

    updateMidiStatus() {
        const midiStatus = document.getElementById('midiStatus');
        if (!midiStatus) return;

        const indicator = midiStatus.querySelector('.status-indicator');
        const value = midiStatus.querySelector('.status-value');

        // MIDI APIのチェック（Safariは対応していない）
        if (!navigator.requestMIDIAccess) {
            if (indicator) {
                indicator.classList.remove('active');
                indicator.classList.add('error');
            }
            if (value) {
                value.textContent = 'Not supported';
                value.style.color = '#ff4444';
            }
            return;
        }

        // MIDI APIが利用可能な場合
        if (indicator) indicator.classList.add('active');
        if (value) value.textContent = 'Available';

        // MIDIデバイスの実際の接続状態をチェック
        navigator.requestMIDIAccess().then(midiAccess => {
            const inputs = midiAccess.inputs.size;
            if (inputs > 0) {
                if (value) {
                    value.textContent = `${inputs} device${inputs > 1 ? 's' : ''}`;
                    value.style.color = 'rgba(255, 255, 255, 0.8)';
                }
            } else {
                if (indicator) {
                    indicator.classList.remove('active');
                    indicator.classList.add('warning');
                }
                if (value) {
                    value.textContent = 'No devices';
                    value.style.color = '#ffaa00';
                }
            }
        }).catch(err => {
            console.error('MIDI access error:', err);
            if (indicator) {
                indicator.classList.remove('active');
                indicator.classList.add('error');
            }
            if (value) {
                value.textContent = 'Error';
                value.style.color = '#ff4444';
            }
        });
    }

    setupControls() {
        // スライダーのプログレス更新関数
        const updateSliderProgress = (slider) => {
            const min = parseFloat(slider.min);
            const max = parseFloat(slider.max);
            const value = parseFloat(slider.value);
            const percentage = ((value - min) / (max - min)) * 100;
            slider.style.setProperty('--progress-start', '0%');
            slider.style.setProperty('--progress-end', percentage + '%');
        };

        // Formant Portamento (ms)
        const formantPortamentoSlider = document.getElementById('formantPortamento');
        const formantPortamentoValue = document.getElementById('formantPortamentoValue');

        const updateFormantPortamento = (ms) => {
            formantPortamentoSlider.value = ms;
            formantPortamentoValue.textContent = Math.round(ms) + 'ms';
            updateSliderProgress(formantPortamentoSlider);
            const speed = this.synth.msToInterpolationSpeed(parseFloat(ms));
            this.synth.setPortamento(speed);
            this.synth.setFormantPortamentoMs(parseFloat(ms));
        };

        formantPortamentoSlider.addEventListener('input', (e) => {
            updateFormantPortamento(e.target.value);
        });

        // 初期値を設定
        updateFormantPortamento(0);

        // Formant Offset
        const formantOffsetSlider = document.getElementById('formantOffset');
        const formantOffsetValue = document.getElementById('formantOffsetValue');

        const updateFormantOffset = (value) => {
            formantOffsetSlider.value = value;
            formantOffsetValue.textContent = (value >= 0 ? '+' : '') + value;
            updateSliderProgress(formantOffsetSlider);
            this.synth.setFormantOffset(parseInt(value));
        };

        formantOffsetSlider.addEventListener('input', (e) => {
            updateFormantOffset(e.target.value);
        });

        // 初期値を設定
        updateFormantOffset(0);

        // Pitch Offset
        const pitchOffsetSlider = document.getElementById('pitchOffset');
        const pitchOffsetValue = document.getElementById('pitchOffsetValue');

        const updatePitchOffset = (value) => {
            pitchOffsetSlider.value = value;
            updateSliderProgress(pitchOffsetSlider);
            pitchOffsetValue.textContent = (value >= 0 ? '+' : '') + value;
            this.synth.setPitchOffset(parseInt(value));
        };

        pitchOffsetSlider.addEventListener('input', (e) => {
            updatePitchOffset(e.target.value);
        });

        // 初期値を設定
        updatePitchOffset(0);

        // Pitch Portamento (ms)
        const pitchPortamentoSlider = document.getElementById('pitchPortamento');
        const pitchPortamentoValue = document.getElementById('pitchPortamentoValue');

        const updatePitchPortamento = (ms) => {
            pitchPortamentoSlider.value = ms;
            updateSliderProgress(pitchPortamentoSlider);
            pitchPortamentoValue.textContent = Math.round(ms) + 'ms';
            const speed = this.synth.msToInterpolationSpeed(parseFloat(ms));
            this.synth.setPitchPortamento(speed);
            this.synth.setPitchPortamentoMs(parseFloat(ms));
        };

        pitchPortamentoSlider.addEventListener('input', (e) => {
            updatePitchPortamento(e.target.value);
        });

        // 初期値を設定
        updatePitchPortamento(0);

        // Vibrato Depth
        const vibratoDepthSlider = document.getElementById('vibratoDepth');
        const vibratoDepthValue = document.getElementById('vibratoDepthValue');

        const updateVibratoDepth = (value) => {
            vibratoDepthSlider.value = value;
            updateSliderProgress(vibratoDepthSlider);
            vibratoDepthValue.textContent = Math.round(value);
            this.synth.setVibratoDepth(parseFloat(value));
        };

        vibratoDepthSlider.addEventListener('input', (e) => {
            updateVibratoDepth(e.target.value);
        });

        // 初期値を設定
        updateVibratoDepth(50);

        // Vibrato Speed
        const vibratoSpeedSlider = document.getElementById('vibratoSpeed');
        const vibratoSpeedValue = document.getElementById('vibratoSpeedValue');

        const updateVibratoSpeed = (value) => {
            vibratoSpeedSlider.value = value;
            updateSliderProgress(vibratoSpeedSlider);
            vibratoSpeedValue.textContent = parseFloat(value).toFixed(1);
            this.synth.setVibratoSpeed(parseFloat(value));
        };

        vibratoSpeedSlider.addEventListener('input', (e) => {
            updateVibratoSpeed(e.target.value);
        });

        // 初期値を設定
        updateVibratoSpeed(5.5);

        // Vibrato Delay
        const vibratoDelaySlider = document.getElementById('vibratoDelay');
        const vibratoDelayValue = document.getElementById('vibratoDelayValue');

        const updateVibratoDelay = (value) => {
            vibratoDelaySlider.value = value;
            updateSliderProgress(vibratoDelaySlider);
            vibratoDelayValue.textContent = Math.round(value) + 'ms';
            this.synth.setVibratoDelay(parseFloat(value));
        };

        vibratoDelaySlider.addEventListener('input', (e) => {
            updateVibratoDelay(e.target.value);
        });

        // 初期値を設定
        updateVibratoDelay(100);

        // Master Volume
        const masterVolumeSlider = document.getElementById('masterVolume');
        const masterVolumeValue = document.getElementById('masterVolumeValue');

        const updateMasterVolume = (value) => {
            masterVolumeSlider.value = value;
            updateSliderProgress(masterVolumeSlider);
            masterVolumeValue.textContent = parseFloat(value).toFixed(2);
            this.synth.setMasterVolume(parseFloat(value));
        };

        masterVolumeSlider.addEventListener('input', (e) => {
            updateMasterVolume(e.target.value);
        });

        // 初期値を設定
        updateMasterVolume(0.5);

        // Resonance Q
        const resonanceQSlider = document.getElementById('resonanceQ');
        const resonanceQValue = document.getElementById('resonanceQValue');

        const updateResonanceQ = (value) => {
            resonanceQSlider.value = value;
            updateSliderProgress(resonanceQSlider);
            resonanceQValue.textContent = parseFloat(value).toFixed(1);
            this.synth.setQ(parseFloat(value));
        };

        resonanceQSlider.addEventListener('input', (e) => {
            updateResonanceQ(e.target.value);
        });

        // 初期値を設定
        updateResonanceQ(18.0);

        // Drive
        const driveSlider = document.getElementById('drive');
        const driveValue = document.getElementById('driveValue');

        const updateDrive = (value) => {
            driveSlider.value = value;
            updateSliderProgress(driveSlider);
            driveValue.textContent = parseFloat(value).toFixed(1);
            this.synth.setDrive(parseFloat(value));
        };

        driveSlider.addEventListener('input', (e) => {
            updateDrive(e.target.value);
        });

        // 初期値を設定
        updateDrive(0.8);

        // Random Formant
        const randomFormantCheckbox = document.getElementById('randomFormant');
        randomFormantCheckbox.addEventListener('change', (e) => {
            this.synth.setRandomFormant(e.target.checked);
        });

        // Vowel Selector
        const vowelButtons = document.querySelectorAll('.vowel-btn');
        vowelButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const vowelIndex = parseInt(e.target.dataset.vowel);
                console.log('Button clicked, Vowel index:', vowelIndex);
                this.synth.setVowel(vowelIndex);
                this.updateVowelButtons(vowelIndex);
            });
        });

        // 初期状態をセット（ア）
        this.updateVowelButtons(0);
    }

    setupBackgroundSelector() {
        const backgroundOptions = document.querySelectorAll('.background-option input[type="radio"]');

        // Set initial background mode to black
        this.synth.setBackgroundMode('black');

        backgroundOptions.forEach(option => {
            option.addEventListener('change', (e) => {
                const mode = e.target.value;
                console.log('Background mode changed to:', mode);
                this.synth.setBackgroundMode(mode);
            });
        });
    }

    setupInfoModal() {
        const infoModal = document.getElementById('infoModal');
        const infoModalClose = document.getElementById('infoModalClose');

        if (!infoModal) return;

        // Close modal with X button (always)
        if (infoModalClose) {
            infoModalClose.addEventListener('click', () => {
                infoModal.classList.remove('active');
            });
        }

        // Close modal by clicking outside (always)
        infoModal.addEventListener('click', (e) => {
            if (e.target === infoModal) {
                infoModal.classList.remove('active');
            }
        });

        // Close modal with Escape key (always)
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && infoModal.classList.contains('active')) {
                infoModal.classList.remove('active');
            }
        });
    }

    setupVirtualKeyboard() {
        this.setupKeySwitches();
        this.setupPianoKeyboard();
    }

    setupKeySwitches() {
        const keySwitchesContainer = document.getElementById('keySwitches');
        if (!keySwitchesContainer) return;

        const keySwitchMap = [
            { note: 24, label: 'A', keyNum: '1' },
            { note: 25, label: 'AE', keyNum: '2' },
            { note: 26, label: 'I', keyNum: '3' },
            { note: 27, label: 'Y', keyNum: '4' },
            { note: 28, label: 'U', keyNum: '5' },
            { note: 29, label: 'E', keyNum: '6' },
            { note: 30, label: 'R', keyNum: '7' },
            { note: 31, label: 'O', keyNum: '8' },
            { note: 32, label: 'W', keyNum: '9' },
            { note: 33, label: 'M', keyNum: '10' },
            { note: 34, label: '', keyNum: '' },
            { note: 35, label: 'N', keyNum: '11' }
        ];

        keySwitchesContainer.innerHTML = '';

        // 白鍵と黒鍵を分けて生成
        let whiteKeyIndex = 0;

        keySwitchMap.forEach(ks => {
            const noteName = this.getNoteName(ks.note);
            const isBlack = noteName.includes('#');
            const key = document.createElement('div');
            key.className = `key-switch ${isBlack ? 'black-key' : 'white-key'}`;
            key.dataset.note = ks.note;

            // フォルマント名とキー番号を表示
            const label = document.createElement('span');
            label.className = 'note-label';
            label.innerHTML = `${ks.label}<br><small>${ks.keyNum}</small>`;
            key.appendChild(label);

            if (isBlack) {
                // 黒鍵の位置を調整
                const prevWhiteKey = keySwitchesContainer.querySelector('.white-key:last-child');
                if (prevWhiteKey) {
                    const prevLeft = prevWhiteKey.offsetLeft;
                    // 白鍵の右端から黒鍵の半分だけ左に配置
                    key.style.left = (prevLeft + 40 - 13) + 'px';
                }
                keySwitchesContainer.appendChild(key);
            } else {
                // 白鍵
                keySwitchesContainer.appendChild(key);
                whiteKeyIndex++;
            }

            // Mouse/touch events
            const handleDown = (e) => {
                e.preventDefault();
                // Clear all key switch active states
                document.querySelectorAll('.key-switch').forEach(k => k.classList.remove('active'));
                key.classList.add('active');

                const vowelIndex = this.getKeySwitchVowel(ks.note);
                this.synth.setVowel(vowelIndex);
                this.updateVowelButtons(vowelIndex);
            };

            const handleUp = (e) => {
                e.preventDefault();
                key.classList.remove('active');
            };

            key.addEventListener('mousedown', handleDown);
            key.addEventListener('mouseup', handleUp);
            key.addEventListener('mouseleave', handleUp);
            key.addEventListener('touchstart', handleDown);
            key.addEventListener('touchend', handleUp);
        });
    }

    getKeySwitchVowel(note) {
        const map = {
            24: 0,  // C1 -> A
            25: 7,  // C#1 -> AE
            26: 1,  // D1 -> I
            27: 8,  // D#1 -> Y
            28: 2,  // E1 -> U
            29: 3,  // F1 -> E
            30: 9,  // F#1 -> R
            31: 4,  // G1 -> O
            32: 10, // G#1 -> W
            33: 5,  // A1 -> M
            35: 6   // B1 -> N
        };
        return map[note] !== undefined ? map[note] : 0;
    }

    setupPianoKeyboard() {
        const pianoKeyboard = document.getElementById('pianoKeyboard');
        if (!pianoKeyboard) return;

        // レガート演奏用の状態管理
        let isDragging = false;
        let currentNote = null;

        // PCキーボードマッピング（keyboardMapと一致させる）
        const pcKeyMap = {
            // 新しい配置: awsedftgyhujkolp;'
            48: 'A', 49: 'W', 50: 'S', 51: 'E', 52: 'D', 53: 'F', 54: 'T',
            55: 'G', 56: 'Y', 57: 'H', 58: 'U', 59: 'J', 60: 'K', 61: 'O',
            62: 'L', 63: 'P', 64: ';', 65: "'"
        };

        pianoKeyboard.innerHTML = '';

        // C2-C6を生成（72音符）
        const startNote = 36; // C2
        const endNote = 84;   // C6

        for (let note = startNote; note <= endNote; note++) {
            const noteName = this.getNoteName(note);
            const isBlack = noteName.includes('#');

            const key = document.createElement('div');
            key.className = `piano-key ${isBlack ? 'black-key' : 'white-key'}`;
            key.dataset.note = note;

            // PCキーボードのキーを表示
            const pcKey = pcKeyMap[note] || '';
            key.innerHTML = `<span>${pcKey}</span>`;

            // 黒鍵の位置を調整
            if (isBlack) {
                const prevWhiteKey = pianoKeyboard.querySelector(`.white-key:last-child`);
                if (prevWhiteKey) {
                    const prevLeft = prevWhiteKey.offsetLeft;
                    // 白鍵の右端から黒鍵の半分だけ左に配置
                    key.style.left = (prevLeft + 40 - 13) + 'px';
                }
            }

            // マウス/タッチイベント（レガート対応）
            const handleDown = (e) => {
                e.preventDefault();
                isDragging = true;
                currentNote = note;

                // 全キーのアクティブ状態をクリア
                document.querySelectorAll('.piano-key').forEach(k => k.classList.remove('active'));
                key.classList.add('active');

                this.synth.noteOn(note);
            };

            key.addEventListener('mousedown', handleDown);
            key.addEventListener('touchstart', handleDown);

            pianoKeyboard.appendChild(key);
        }

        // グローバルマウスイベント（レガート演奏用）
        const handleGlobalMove = (e) => {
            if (!isDragging) return;

            // タッチまたはマウスイベントから座標を取得
            const clientX = e.touches ? e.touches[0].clientX : e.clientX;
            const clientY = e.touches ? e.touches[0].clientY : e.clientY;

            // マウス下の要素を取得
            const element = document.elementFromPoint(clientX, clientY);
            if (!element) return;

            const key = element.closest('.piano-key');
            if (!key) return;

            const newNote = parseInt(key.dataset.note);
            if (newNote !== currentNote) {
                // 音が変わった場合のみ切り替え
                document.querySelectorAll('.piano-key').forEach(k => k.classList.remove('active'));
                key.classList.add('active');

                this.synth.noteOn(newNote);
                currentNote = newNote;
            }
        };

        const handleGlobalUp = (e) => {
            if (!isDragging) return;

            isDragging = false;
            document.querySelectorAll('.piano-key').forEach(k => k.classList.remove('active'));
            this.synth.noteOff();
            currentNote = null;
        };

        // グローバルイベントをキーボードスクロール領域に追加
        const pianoScroll = document.querySelector('.piano-keyboard-scroll');
        if (pianoScroll) {
            pianoScroll.addEventListener('mousemove', handleGlobalMove);
            pianoScroll.addEventListener('mouseup', handleGlobalUp);
            pianoScroll.addEventListener('mouseleave', handleGlobalUp);
            pianoScroll.addEventListener('touchmove', handleGlobalMove, { passive: false });
            pianoScroll.addEventListener('touchend', handleGlobalUp);
            pianoScroll.addEventListener('touchcancel', handleGlobalUp);
        }
    }

    getNoteName(note) {
        const notes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
        const octave = Math.floor(note / 12) - 1;
        const noteIndex = note % 12;
        return notes[noteIndex] + octave;
    }

    updateVowelButtons(activeIndex) {
        const vowelButtons = document.querySelectorAll('.vowel-btn');
        const indicator = document.querySelector('.vowel-selector .active-indicator');
        const vowelSelector = document.getElementById('vowelSelector');

        if (!vowelSelector || !indicator) return;

        // Wait for layout to be ready
        requestAnimationFrame(() => {
            const selectorRect = vowelSelector.getBoundingClientRect();
            const padding = 4; // matches CSS padding
            const availableWidth = selectorRect.width - (padding * 2);
            const totalButtons = vowelButtons.length;
            const buttonWidth = availableWidth / totalButtons;

            vowelButtons.forEach((btn) => {
                const btnVowelIndex = parseInt(btn.dataset.vowel);
                if (btnVowelIndex === activeIndex) {
                    btn.classList.add('is-active');
                    btn.classList.remove('active');
                } else {
                    btn.classList.remove('is-active');
                    btn.classList.remove('active');
                }
            });

            // Update indicator position and width
            indicator.style.width = buttonWidth + 'px';
            indicator.style.transform = `translateX(${activeIndex * buttonWidth}px)`;
        });
    }

    setupKeyboard() {
        document.addEventListener('keydown', (e) => {
            if (e.repeat) return;

            const key = e.key.toLowerCase();

            // 母音切り替え (1-6)
            if (vowelMap.hasOwnProperty(key)) {
                const vowelIndex = vowelMap[key];
                console.log('Key pressed:', key, 'Vowel index:', vowelIndex);
                this.synth.setVowel(vowelIndex);
                this.updateVowelButtons(vowelIndex);
                return;
            }

            // オクターブシフト (Z/X)
            if (key === 'z' || key === 'Z') {
                this.synth.octaveShift = Math.max(this.synth.octaveShift - 1, -3);
                console.log('Octave down:', this.synth.octaveShift);
                return;
            }
            if (key === 'x' || key === 'X') {
                this.synth.octaveShift = Math.min(this.synth.octaveShift + 1, 3);
                console.log('Octave up:', this.synth.octaveShift);
                return;
            }

            // ノートオン（レガート対応）
            if (keyboardMap[key]) {
                const note = keyboardMap[key] + (this.synth.octaveShift * 12);
                this.synth.noteOn(note);
                this.activeNotes.set(key, note); // 押されているノートを記録

                // 仮想ピアノキーボードをハイライト
                this.highlightPianoKey(note, true);

                // ランダムフォルマントがONなら、ボタンの表示も更新
                if (this.synth.randomFormant) {
                    this.updateVowelButtons(this.synth.currentVowel);
                }
            }
        });

        document.addEventListener('keyup', (e) => {
            const key = e.key.toLowerCase();

            // ノートオフ（レガート対応）
            if (this.activeNotes.has(key)) {
                const note = this.activeNotes.get(key);
                this.activeNotes.delete(key);

                // 仮想ピアノキーボードのハイライトを解除
                this.highlightPianoKey(note, false);

                // 全てのキーが離された時だけ音を止める
                if (this.activeNotes.size === 0) {
                    this.synth.noteOff();
                }
            }
        });
    }

    highlightPianoKey(note, active) {
        const pianoKey = document.querySelector(`.piano-key[data-note="${note}"]`);
        if (pianoKey) {
            if (active) {
                pianoKey.classList.add('active');
            } else {
                pianoKey.classList.remove('active');
            }
        }
    }
}

// MIDI Input Handler
class MidiInputHandler {
    constructor(synth) {
        this.synth = synth;
        this.midiAccess = null;
        this.activeInputs = new Map();
        this.init();
    }

    async init() {
        try {
            if (navigator.requestMIDIAccess) {
                this.midiAccess = await navigator.requestMIDIAccess();
                console.log('Web MIDI API initialized');
                this.setupInputs();
                this.handleStateChanges();
            } else {
                console.warn('Web MIDI API not supported in this browser');
            }
        } catch (error) {
            console.error('MIDI access denied:', error);
        }
    }

    setupInputs() {
        for (let [id, input] of this.midiAccess.inputs) {
            this.attachInput(input);
        }
        console.log(`Connected MIDI inputs: ${this.midiAccess.inputs.size}`);
    }

    attachInput(input) {
        input.onmidimessage = (message) => {
            this.handleMessage(message);
        };
        this.activeInputs.set(input.id, input);
        console.log('MIDI input connected:', input.name);
    }

    handleMessage(message) {
        const [status, note, velocity] = message.data;

        // Note On (status = 144, velocity > 0)
        if (status === 144 && velocity > 0) {
            // キースイッチ判定（C1-B1: 24-35）
            if (note >= 24 && note <= 35) {
                this.handleKeySwitch(note);
            } else {
                this.synth.noteOn(note);
                console.log('MIDI Note On:', note, 'velocity:', velocity);
            }
        }
        // Note Off (status = 128, or status = 144 with velocity = 0)
        else if (status === 128 || (status === 144 && velocity === 0)) {
            // キースイッチはnoteOffを送らない
            if (note < 24 || note > 35) {
                this.synth.noteOff();
                console.log('MIDI Note Off:', note);
            }
        }
    }

    handleKeySwitch(note) {
        const keySwitchMap = {
            24: 0,  // C1 -> A (ア)
            25: 7,  // C#1 -> AE (アエ)
            26: 1,  // D1 -> I (イ)
            27: 8,  // D#1 -> Y (ユ)
            28: 2,  // E1 -> U (ウ)
            29: 3,  // F1 -> E (エ)
            30: 9,  // F#1 -> R (ル)
            31: 4,  // G1 -> O (オ)
            32: 10, // G#1 -> W (ウ)
            33: 5,  // A1 -> M (ン)
            35: 6   // B1 -> N (ン)
        };

        const vowelIndex = keySwitchMap[note];
        if (vowelIndex !== undefined) {
            const vowelNames = ['A', 'I', 'U', 'E', 'O', 'M', 'N', 'AE', 'Y', 'R', 'W'];
            console.log(`KeySwitch: ${note} -> ${vowelNames[vowelIndex]}`);
            this.synth.setVowel(vowelIndex);
        }
    }

    handleStateChanges() {
        this.midiAccess.onstatechange = (event) => {
            if (event.port.type === 'input') {
                if (event.port.state === 'connected') {
                    this.attachInput(event.port);
                } else {
                    this.activeInputs.delete(event.port.id);
                    console.log('MIDI input disconnected:', event.port.name);
                }
            }
        };
    }
}

// Wave Distortion Engine
class WaveDistortion {
    constructor(canvas) {
        this.canvas = canvas;
        // Enable antialiasing
        this.ctx = canvas.getContext('2d', {
            willReadFrequently: true,
            alpha: false // Disable alpha channel for better performance
        });

        // Set image smoothing for better quality
        this.ctx.imageSmoothingEnabled = true;
        this.ctx.imageSmoothingQuality = 'high';

        // Use fixed dimensions (matching image aspect ratio 1024x837)
        // This avoids DPR scaling issues and layout dependencies
        canvas.width = 1024;
        canvas.height = 837;

        this.amplitude = 15;
        this.frequency = 0.02;

        // Preload all vowel images
        this.vowelImages = {};
        ['a', 'i', 'u', 'ye', 'o', 'm', 'n', 'ae', 'y', 'r', 'w'].forEach(vowel => {
            const img = new Image();
            img.src = vowel + '.png';
            this.vowelImages[vowel] = img;
        });

        // Preload sleeping image
        this.sleepingImage = new Image();
        this.sleepingImage.src = 'sleeping.png';

        // Preload 'a' image for startup
        this.startupImage = new Image();
        this.startupImage.src = 'a.png';

        // Initially show sleeping image
        this.showingSleeping = true;

        // Create offscreen canvas for reuse (memory leak fix)
        this.offscreenCanvas = document.createElement('canvas');
        this.offscreenCanvas.width = canvas.width;
        this.offscreenCanvas.height = canvas.height;
        this.offscreenCtx = this.offscreenCanvas.getContext('2d');
        this.offscreenCtx.imageSmoothingEnabled = true;
        this.offscreenCtx.imageSmoothingQuality = 'high';
    }

    drawSleepingImage() {
        // Draw sleeping image without distortion
        const width = this.canvas.width;
        const height = this.canvas.height;

        // Draw background first
        this.drawBackground();

        // Draw sleeping image
        if (this.sleepingImage && this.sleepingImage.complete) {
            this.ctx.globalAlpha = 1.0;
            this.ctx.drawImage(this.sleepingImage, 0, 0, width, height);
        }
    }

    distort(x, y, time, amplitude) {
        // 横方向の波形歪み計算（amplitudeを外から受け取る）
        let waveX;

        // 複数の周波数を重ねてより細かい波形に
        const wave1 = Math.sin((y * this.frequency * 2) + time);
        const wave2 = Math.sin((y * this.frequency) + time * 1.3) * 0.5;
        const wave3 = Math.cos((y * this.frequency * 0.6) + time * 0.7) * 0.3;

        waveX = (wave1 + wave2 + wave3) * amplitude;

        return { x: waveX, y: 0 }; // Y方向は歪まない
    }

    drawLayers(baseImage, frontImage, eyeImage = null, eyeOpacity = 0) {
        // Use canvas dimensions directly (no DPR scaling)
        const width = this.canvas.width;
        const height = this.canvas.height;

        // Draw background first
        this.drawBackground();

        // If showing sleeping image, draw it instead
        if (this.showingSleeping && this.sleepingImage && this.sleepingImage.complete) {
            this.ctx.globalAlpha = 1.0;
            this.ctx.drawImage(this.sleepingImage, 0, 0, width, height);
            return;
        }

        // Use DOM images
        const actualBaseImage = baseImage;
        const actualFrontImage = frontImage;

        // Clear and draw layers (canvas aspect ratio matches image)
        // Note: Don't clearRect here as we just drew the background

        this.ctx.globalAlpha = 1.0;
        this.ctx.drawImage(actualBaseImage, 0, 0, width, height);
        this.ctx.drawImage(actualFrontImage, 0, 0, width, height);

        // Draw eye effect
        if (eyeImage && eyeOpacity > 0) {
            this.ctx.globalAlpha = eyeOpacity;
            this.ctx.drawImage(eyeImage, 0, 0, width, height);
            this.ctx.globalAlpha = 1.0;
        }
    }

    drawLayersWithDistortion(baseImage, frontImage, eyeImage = null, eyeOpacity = 0, lfoTime = 0, amplitude = 7.5) {
        // Use canvas dimensions directly (no DPR scaling)
        const width = this.canvas.width;
        const height = this.canvas.height;

        // Draw background first
        this.drawBackground();

        // If showing sleeping image, draw it without distortion
        if (this.showingSleeping && this.sleepingImage && this.sleepingImage.complete) {
            this.ctx.globalAlpha = 1.0;
            this.ctx.drawImage(this.sleepingImage, 0, 0, width, height);
            return;
        }

        // Use passed images (note-on state)
        const actualBaseImage = baseImage;
        const actualFrontImage = frontImage;

        // Reuse offscreen canvas (memory leak fix)
        const offscreenCtx = this.offscreenCtx;

        // Draw background to offscreen canvas
        const synth = window.app?.synth;
        const mode = synth?.backgroundMode || 'black';
        switch(mode) {
            case 'green':
                offscreenCtx.fillStyle = '#00ff00';
                offscreenCtx.fillRect(0, 0, width, height);
                break;
            case 'blue':
                offscreenCtx.fillStyle = '#0066ff';
                offscreenCtx.fillRect(0, 0, width, height);
                break;
            case 'black':
            default:
                offscreenCtx.fillStyle = '#000000';
                offscreenCtx.fillRect(0, 0, width, height);
                break;
        }

        // Draw layers to entire canvas (aspect ratio matches)
        offscreenCtx.drawImage(actualBaseImage, 0, 0, width, height);
        offscreenCtx.globalAlpha = 1.0;
        offscreenCtx.drawImage(actualFrontImage, 0, 0, width, height);

        if (eyeImage && eyeOpacity > 0) {
            offscreenCtx.globalAlpha = eyeOpacity;
            offscreenCtx.drawImage(eyeImage, 0, 0, width, height);
        }

        // Get ImageData from canvas
        const imageData = offscreenCtx.getImageData(0, 0, width, height);
        const sourceData = imageData.data;

        // Create output buffer (copy of source data)
        const outputData = new Uint8ClampedArray(sourceData);

        // Apply wave distortion pixel by pixel (LFO synced)
        for (let y = 0; y < height; y++) {
            for (let x = 0; x < width; x++) {
                const pixelIndex = (y * width + x) * 4;
                const alpha = sourceData[pixelIndex + 3];

                // Copy transparent pixels as-is
                if (alpha < 10) {
                    continue;
                }

                // Apply distortion to image pixels
                const distortion = this.distort(x - width/2, y - height/2, lfoTime, amplitude);

                const distortedX = Math.floor(x - distortion.x);
                const distortedY = Math.floor(y);

                // Boundary check
                if (distortedX >= 0 && distortedX < width && distortedY >= 0 && distortedY < height) {
                    const distortedIndex = (distortedY * width + distortedX) * 4;

                    // Only copy if source pixel is not transparent
                    if (sourceData[distortedIndex + 3] > 10) {
                        outputData[pixelIndex] = sourceData[distortedIndex];
                        outputData[pixelIndex + 1] = sourceData[distortedIndex + 1];
                        outputData[pixelIndex + 2] = sourceData[distortedIndex + 2];
                        outputData[pixelIndex + 3] = sourceData[distortedIndex + 3];
                    }
                }
            }
        }

        // Clear main canvas and draw distorted image
        this.ctx.clearRect(0, 0, width, height);
        const outputImageData = new ImageData(outputData, width, height);
        this.ctx.putImageData(outputImageData, 0, 0);
    }

    clear() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }

    drawBackground() {
        const width = this.canvas.width;
        const height = this.canvas.height;

        // Get background mode from synth instance
        const synth = window.app?.synth;
        const mode = synth?.backgroundMode || 'black';

        switch(mode) {
            case 'green':
                this.ctx.fillStyle = '#00ff00';
                this.ctx.fillRect(0, 0, width, height);
                break;
            case 'blue':
                this.ctx.fillStyle = '#0066ff';
                this.ctx.fillRect(0, 0, width, height);
                break;
            case 'black':
            default:
                this.ctx.fillStyle = '#000000';
                this.ctx.fillRect(0, 0, width, height);
                break;
        }
    }
}

// アプリケーション開始
window.addEventListener('DOMContentLoaded', () => {
    try {
        window.app = new App();
    } catch (error) {
        console.error('App initialization error:', error);
        alert('Error initializing application: ' + error.message);
    }
});
