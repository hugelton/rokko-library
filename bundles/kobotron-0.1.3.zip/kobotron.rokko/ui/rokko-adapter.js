// Connects Kobotron's web page (app.js, unchanged) to Rokko (docs/BUNDLE_UI.md).
// In the web demo the page ran the Komyo wasm itself through Web Audio. Here the bundle's DSP runs in the host, so:
// - `engine` stands in for that wasm module: its __set*/__note* calls become rokko.setParam / noteOn / noteOff;
// - KomyoSynth's audio start is replaced by its visual part (face, blinking, wave distortion);
// - values from the host (rokko-init, rokko-param) and notes the plugin receives (rokko-note) drive the page
//   without being sent back.
(() => {
    'use strict';

    // Bundle parameter ids (kobotron.cpp) and their UI ranges: normalized <-> what the sliders show.
    const P = { vowel: 0, random: 1, formant: 2, formantPort: 3, pitch: 4, pitchPort: 5,
                vibDepth: 6, vibSpeed: 7, vibDelay: 8, volume: 9, q: 10, drive: 11 };
    const sliders = {  // slider id -> [param id, to normalized, from normalized]
        formantOffset:     [P.formant,     v => (v + 12) / 24,          n => Math.round(n * 24 - 12)],
        formantPortamento: [P.formantPort, v => Math.sqrt(v / 3000),    n => Math.round(n * n * 3000)],
        pitchOffset:       [P.pitch,       v => (v + 12) / 24,          n => Math.round(n * 24 - 12)],
        pitchPortamento:   [P.pitchPort,   v => Math.sqrt(v / 3000),    n => Math.round(n * n * 3000)],
        vibratoDepth:      [P.vibDepth,    v => v / 200,                n => n * 200],
        vibratoSpeed:      [P.vibSpeed,    v => (v - 1) / 14,           n => 1 + n * 14],
        vibratoDelay:      [P.vibDelay,    v => v / 1000,               n => n * 1000],
        masterVolume:      [P.volume,      v => v,                      n => n],
        resonanceQ:        [P.q,           v => (v - 1) / 49,           n => 1 + n * 49],
        drive:             [P.drive,       v => v / 2,                  n => n * 2],
    };
    const keySwitchVowel = [0, 7, 1, 8, 2, 3, 9, 4, 10, 5, 0, 6];  // notes 24..35, as in the DSP

    let muted = false;      // while the page shows what the host sent, nothing goes back
    let muteVowel = false;  // the random vowel is the DSP's: the page only shows a face for it
    const clamp01 = x => Math.min(1, Math.max(0, x));
    const send = (id, n) => { if (!muted) rokko.setParam(id, clamp01(n)); };
    const withMute = f => { const was = muted; muted = true; try { f(); } finally { muted = was; } };

    // Notes the page plays. The plugin echoes every note it gets as rokko-note; the page's own are skipped.
    let pageNote = null;
    const own = { on: new Map(), off: new Map() };
    const mark = (m, n) => m.set(n, (m.get(n) || 0) + 1);
    const pageOn = n => { if (pageNote !== null && pageNote !== n) pageOff(); rokko.noteOn(n, 100); mark(own.on, n); pageNote = n; };
    function pageOff() { if (pageNote === null) return; rokko.noteOff(pageNote); mark(own.off, pageNote); pageNote = null; }

    const engine = {
        __init() {}, __process() { return 0; }, __clear() {},
        __setVowel: i => { if (!muteVowel) send(P.vowel, i / 10); },
        __setPortamento() {}, __setPitchPortamento() {},  // the page passes milliseconds via set*PortamentoMs
        __setFormantOffset: v => send(P.formant, (v + 12) / 24),
        __setPitchOffset: v => send(P.pitch, (v + 12) / 24),
        __setVibratoDepth: v => send(P.vibDepth, v / 200),
        __setVibratoSpeed: v => send(P.vibSpeed, (v - 1) / 14),
        __setVibratoDelay: v => send(P.vibDelay, v / 1000),
        __setMasterVolume: v => send(P.volume, v),
        __setQ: v => send(P.q, (v - 1) / 49),
        __setDrive: v => send(P.drive, v / 2),
        __noteOn: n => { if (!muted) pageOn(n | 0); },
        __noteOff: () => { if (!muted) pageOff(); },
    };

    const S = KomyoSynth.prototype;
    S.init = async function () { this.wasmModule = engine; return true; };
    S.start = function () {  // KomyoSynth.start without the audio graph
        if (this.isPlaying) return;
        this.isPlaying = true;
        if (this.waveDistortion) this.waveDistortion.showingSleeping = false;
        this.startIdleBlinking();
        this.startAnimationLoop();
    };
    const setFormantMs = S.setFormantPortamentoMs, setPitchMs = S.setPitchPortamentoMs;
    S.setFormantPortamentoMs = function (ms) { setFormantMs.call(this, ms); send(P.formantPort, Math.sqrt(ms / 3000)); };
    S.setPitchPortamentoMs = function (ms) { setPitchMs.call(this, ms); send(P.pitchPort, Math.sqrt(ms / 3000)); };
    const setRandom = S.setRandomFormant;
    S.setRandomFormant = function (on) { setRandom.call(this, on); send(P.random, on ? 1 : 0); };
    const noteOn = S.noteOn;
    S.noteOn = function (n) { muteVowel = this.randomFormant; try { noteOn.call(this, n); } finally { muteVowel = false; } };

    // The face is drawn per pixel in JS. Draw it at half the demo's 1024 x 837 (the area shows it at 300 px), with
    // the wave computed in the demo's pixel units so it looks the same.
    const distort = WaveDistortion.prototype.distort;
    WaveDistortion.prototype.distort = function (x, y, time, amplitude) {
        const k = 1024 / this.canvas.width, d = distort.call(this, x * k, y * k, time, amplitude);
        return { x: d.x / k, y: d.y / k };
    };
    // The demo reads the composed face back with getImageData to shift each row. A page loaded from file:// may
    // not read pixels of its own images (the canvas counts as tainted), so it threw on the first note and the face
    // went black. The wave only moves rows sideways, so draw each row shifted instead: same picture, no pixel reads.
    WaveDistortion.prototype.drawLayersWithDistortion = function (base, front, eye = null, eyeOpacity = 0, lfoTime = 0, amplitude = 7.5) {
        const w = this.canvas.width, h = this.canvas.height, ctx = this.ctx, off = this.offscreenCtx;
        this.drawBackground();
        if (this.showingSleeping && this.sleepingImage && this.sleepingImage.complete) {
            ctx.globalAlpha = 1; ctx.drawImage(this.sleepingImage, 0, 0, w, h); return;
        }
        // compose into the offscreen canvas as the demo does: background, base, front, eyes
        const bg = { green: '#00ff00', blue: '#0066ff' }[window.app?.synth?.backgroundMode] || '#000000';
        off.globalAlpha = 1; off.fillStyle = bg; off.fillRect(0, 0, w, h);
        off.drawImage(base, 0, 0, w, h); off.drawImage(front, 0, 0, w, h);
        if (eye && eyeOpacity > 0) { off.globalAlpha = eyeOpacity; off.drawImage(eye, 0, 0, w, h); off.globalAlpha = 1; }
        // the demo's per-pixel loop takes source x - shift, keeping the pixel where that falls outside: draw the
        // picture unshifted, then each row moved right by ceil(shift)
        ctx.globalAlpha = 1;
        ctx.drawImage(this.offscreenCanvas, 0, 0);
        for (let y = 0; y < h; y++) {
            const dx = Math.ceil(this.distort(0, y - h / 2, lfoTime, amplitude).x);
            if (dx !== 0) ctx.drawImage(this.offscreenCanvas, 0, y, w, 1, dx, y, w, 1);
        }
    };

    // At rest the demo redraws the same three pictures 60 times a second. Draw only when something it shows changed.
    const drawLayers = WaveDistortion.prototype.drawLayers;
    WaveDistortion.prototype.drawLayers = function (base, front, eye = null, eyeOpacity = 0) {
        const key = [base && base.src, front && front.src, eye && eye.src, eyeOpacity, this.showingSleeping,
                     window.app?.synth?.backgroundMode, base && base.complete, front && front.complete].join('|');
        if (key === this.rokkoLastStill) return;
        this.rokkoLastStill = key;
        drawLayers.call(this, base, front, eye, eyeOpacity);
    };
    const drawDistorted = WaveDistortion.prototype.drawLayersWithDistortion;
    WaveDistortion.prototype.drawLayersWithDistortion = function (...a) { this.rokkoLastStill = null; return drawDistorted.apply(this, a); };

    function shrinkCanvas(wd) {
        for (const c of [wd.canvas, wd.offscreenCanvas]) { c.width = 512; c.height = 419; }
        for (const ctx of [wd.ctx, wd.offscreenCtx]) { ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high'; }
    }

    // host -> page
    function show(id, n) {
        const app = window.app;
        withMute(() => {
            if (id === P.vowel) { const v = Math.round(n * 10); app.synth.setVowel(v); app.updateVowelButtons(v); return; }
            if (id === P.random) { const box = document.getElementById('randomFormant'); box.checked = n > 0.5; box.dispatchEvent(new Event('change')); return; }
            for (const [el, [pid, , fromN]] of Object.entries(sliders)) {
                if (pid !== id) continue;
                const s = document.getElementById(el);
                s.value = fromN(n);
                s.dispatchEvent(new Event('input'));
            }
        });
    }

    const hostHeld = new Set();
    function hostNote(n, on) {
        const app = window.app, synth = app.synth;
        const mine = on ? own.on : own.off;
        if (mine.get(n)) { mine.set(n, mine.get(n) - 1); return; }  // the echo of a note the page played
        if (firstNote && on) { firstNote = false; rokko.log('kobotron: first note from the host ' + n); }
        withMute(() => {
            if (n >= 24 && n <= 35) { if (on) { const v = keySwitchVowel[n - 24]; synth.setVowel(v); app.updateVowelButtons(v); } return; }
            if (on) { hostHeld.add(n); synth.noteOn(n); if (synth.randomFormant) app.updateVowelButtons(synth.currentVowel); }
            else { hostHeld.delete(n); if (hostHeld.size === 0 && pageNote === null) synth.noteOff(); }
            if (app.highlightPianoKey) app.highlightPianoKey(n, on);
        });
    }

    // A page loaded from file:// hides the text of uncaught errors ("Script error."): report them from here.
    const report = (where, err) => rokko.log('kobotron: ' + where + ' ' + (err && err.stack ? err.stack.split('\n').slice(0, 3).join(' | ') : String(err)));
    const raf = window.requestAnimationFrame.bind(window), st = window.setTimeout.bind(window);
    window.requestAnimationFrame = f => raf(t => { try { f(t); } catch (e) { report('frame', e); throw e; } });
    window.setTimeout = (f, ms, ...a) => st(typeof f === 'function' ? () => { try { f(...a); } catch (e) { report('timer', e); throw e; } } : f, ms);

    // A few lines in the player's log, so a run without a screen can tell the page works.
    let firstNote = true, firstParam = true;
    addEventListener('error', e => rokko.log('kobotron: error ' + e.message + ' (' + (e.filename || '').split('/').pop() + ':' + e.lineno + ')'));

    // The kit keyboard (bundles/kit) in place of the demo's two rows: C1..B1 are the key switches (vowels), as in
    // the DSP; C2..C6 play, mono and legato as the demo's keyboard did. Keys light from rokko-note, the page's own too.
    const ksLabels = ['A', 'AE', 'I', 'Y', 'U', 'E', 'R', 'O', 'W', 'M', '', 'N'];
    function mountKeyboard(app) {
        const synth = app.synth, marks = { 48: 'C3', 60: 'C4', 72: 'C5' };
        ksLabels.forEach((t, i) => { if (t) marks[24 + i] = t; });
        const kb = Kit.keyboard({ first: 24, last: 84, zone: [24, 35], marks,
            press(n) {
                if (n < 36) { const v = keySwitchVowel[n - 24]; synth.setVowel(v); app.updateVowelButtons(v); return; }
                synth.noteOn(n);
            },
            release(n) { if (n >= 36) synth.noteOff(); } });
        document.getElementById('keyboardUI').appendChild(kb.el);
    }

    let started = false;
    async function start(detail) {
        const app = window.app, synth = app.synth;
        muted = true;  // setupControls sets the demo's defaults; the host's values follow
        try {
            await synth.init();
            app.setupControls();
            app.setupBackgroundSelector();
            app.setupVirtualKeyboard();   // the PC-key mapping; its two on-screen rows are hidden (rokko.css)
            mountKeyboard(app);
            synth.start();
            for (const id of ['leftColumn', 'controls', 'keyboardUI']) document.getElementById(id).classList.remove('disabled');
        } finally { muted = false; }
        for (const p of detail.params || []) show(p.id, p.value);
        // gestures: one automation gesture per slider drag
        for (const [el, [pid]] of Object.entries(sliders)) {
            const s = document.getElementById(el);
            s.addEventListener('pointerdown', () => rokko.begin(pid));
            s.addEventListener('pointerup', () => rokko.end(pid));
            s.addEventListener('pointercancel', () => rokko.end(pid));
        }
        started = true;
        rokko.log('kobotron: page started, ' + (detail.params || []).length + ' params from the host');
    }

    addEventListener('rokko-init', e => { if (!started) start(e.detail).catch(err => rokko.log('kobotron: ' + err)); });
    addEventListener('rokko-param', e => {
        if (!started) return;
        show(e.detail.id, e.detail.value);
        if (firstParam) { firstParam = false; rokko.log('kobotron: first value from the host, param ' + e.detail.id + ' = ' + e.detail.value.toFixed(3)); }
    });
    addEventListener('rokko-note', e => {
        if (!started) return;
        hostNote(e.detail.note, e.detail.on);
    });
    addEventListener('DOMContentLoaded', () => {  // after app.js's own handler has made window.app
        if (window.app && window.app.synth.waveDistortion) shrinkCanvas(window.app.synth.waveDistortion);
        rokko.ready();
    });
})();
