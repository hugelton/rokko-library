// The lyric parser of the page: text -> syllables, the same rules as libshomyo's shomyo_parse_kana / _ipa / _arpabet
// (src/lib/shomyo_phon.c; phon-data.js is generated from it, so the phoneme ids agree), and the packing of a syllable
// into the three numbers the DSP reads (shomyo.c, "the lyric"). Checked against the C parsers by
// bundles/src/shomyo/check_lyric.mjs.
const Lyric = (() => {
  const { PH, ALIAS, ARPA, KANA } = PHON;
  const STOP = 1, C_VOWEL = 0;
  const idOf = sym => PH.findIndex(p => p[0] === sym);
  const isVowel = id => id >= 0 && PH[id][1] === C_VOWEL;
  const S = sym => idOf(sym);

  // the longest phoneme (or alias) at pos: [id, length] or null
  function nextPhon(str, pos) {
    let best = -1, bl = 0;
    for (let i = 0; i < PH.length; i++) { const l = PH[i][0].length; if (l > bl && str.startsWith(PH[i][0], pos)) { best = i; bl = l; } }
    for (const [a, b] of ALIAS) { const l = a.length; if (l > bl && str.startsWith(a, pos)) { best = idOf(b); bl = l; } }
    return best >= 0 ? [best, bl] : null;
  }
  function onsetPair(a, b) {
    const ca = PH[a][1], cb = PH[b][1];   // 1 stop 2 fric 4 nasal 5 liquid 7 glide
    if ((ca === 1 || a === S('f') || a === S('v') || a === S('θ')) && (cb === 5 || cb === 7)) return true;
    if (a === S('s') && (cb === 1 || cb === 4 || cb === 5 || cb === 7)) return true;
    if ((ca === 1 || ca === 2 || ca === 4) && cb === 7) return true;
    return false;
  }
  const newSyl = () => ({ onset: [], nucleus: -1, nucleus2: -1, coda: [], flags: 0 });

  // items: [{id, brk, lng}]
  function syllabify(it) {
    const out = [], n = it.length;
    let i = 0, carry = [];
    while (i < n) {
      if (!isVowel(it[i].id)) {
        const run = []; let j = i;
        while (j < n && !isVowel(it[j].id) && !(j > i && it[j].brk) && run.length < 8) run.push(it[j++].id);
        const hasVowelNext = j < n && isVowel(it[j].id) && !it[j].brk;
        if (!hasVowelNext && out.length > 0 && !it[i].brk) {
          const p = out[out.length - 1];
          for (const r of run) if (p.coda.length < 3) p.coda.push(r);
          i = j; continue;
        }
        const nr = run.length; let onset = nr;
        if (out.length > 0 && !it[i].brk) {
          onset = nr >= 2 && onsetPair(run[nr - 2], run[nr - 1]) ? 2 : 1;
          if (nr === 1) onset = 1;
          const p = out[out.length - 1];
          for (let k = 0; k < nr - onset; k++) if (p.coda.length < 3) p.coda.push(run[k]);
        } else if (onset > 3) onset = 3;
        carry = [];
        for (let k = nr - onset; k < nr && carry.length < 3; k++) carry.push(run[k]);
        i = j; continue;
      }
      const s = newSyl();
      s.onset = carry.slice(0, 3); carry = [];
      s.nucleus = it[i].id;
      if (it[i].lng) s.flags |= 1;
      i++;
      if (i < n && isVowel(it[i].id) && !it[i].brk) { s.nucleus2 = it[i].id; i++; }
      out.push(s);
    }
    if (carry.length && out.length) { const p = out[out.length - 1]; for (const c of carry) if (p.coda.length < 3) p.coda.push(c); }
    return out;
  }

  function parseIpa(u) {
    const it = []; let brk = 0, p = 0;
    while (p < u.length && it.length < 256) {
      const c = u[p];
      if (' .-\n\t,/[]'.includes(c)) { brk = 1; p++; continue; }
      if (c === 'ː' || c === ':') { if (it.length) it[it.length - 1].lng = 1; p++; continue; }
      if (c === 'ˈ' || c === 'ˌ') { brk = 1; p++; continue; }
      if ('ʲʰ̃ʼ'.includes(c)) { p++; continue; }
      const m = nextPhon(u, p);
      if (!m) { p++; continue; }
      it.push({ id: m[0], brk, lng: 0 }); brk = 0; p += m[1];
    }
    return syllabify(it);
  }

  function parseArpabet(u) {
    const it = []; let brk = 0;
    for (const raw of u.split(/(\s+|\|)/)) {
      if (!raw || /^\s+$/.test(raw)) continue;
      if (raw === '|') { brk = 1; continue; }
      let stress = -1, tok = '';
      for (const ch of raw) { if (ch >= '0' && ch <= '2') stress = +ch; else tok += ch.toUpperCase(); }
      const e = ARPA.find(x => x[0] === tok);
      if (!e) continue;
      let a = e[1];
      if (tok === 'AH' && stress === 0) a = 'ə';
      if (tok === 'ER' && stress === 0) a = 'ɚ';
      const id = idOf(a); if (id < 0) continue;
      it.push({ id, brk, lng: 0 }); brk = 0;
      if (e[2]) it.push({ id: idOf(e[2]), brk: 0, lng: 0 });
    }
    return syllabify(it);
  }

  function parseKana(u) {
    const out = [], cps = Array.from(u, ch => ch.codePointAt(0));
    let geminate = false, lastVowel = -1, pre = '';          // pre: a small tsu waiting for its syllable (shown with it)
    const norm = c => (c >= 0x30A1 && c <= 0x30F6 ? c - 0x60 : c);
    for (let i = 0; i < cps.length; i++) {
      const c = norm(cps[i]);
      if (c === 0x3063) { geminate = true; pre += String.fromCodePoint(cps[i]); continue; }
      if (c === 0x30FC) { if (lastVowel >= 0) { const s = newSyl(); s.nucleus = lastVowel; s.flags = 1; s.src = 'ー'; out.push(s); } continue; }
      if (c === 0x3093) { const s = newSyl(); s.nucleus = idOf('ɴ'); s.src = String.fromCodePoint(cps[i]); out.push(s); geminate = false; pre = ''; continue; }
      const k = KANA[String.fromCodePoint(c)];
      if (!k) continue;
      const s = newSyl();
      s.src = pre + String.fromCodePoint(cps[i]); pre = '';
      if (k[0]) s.onset.push(idOf(k[0]));
      s.nucleus = idOf(k[1]);
      const d = i + 1 < cps.length ? norm(cps[i + 1]) : 0;
      if (d === 0x3083 || d === 0x3085 || d === 0x3087) {
        if (s.onset.length === 0) s.onset.push(idOf('j'));
        else if (![S('ʃ'), S('dʒ'), S('tʃ'), S('ç')].includes(s.onset[0])) s.onset.push(idOf('j'));
        s.nucleus = idOf(d === 0x3083 ? 'a' : d === 0x3085 ? 'ɯ' : 'o');
        s.src += String.fromCodePoint(cps[i + 1]);
        i++;
      } else if (d === 0x3041 || d === 0x3043 || d === 0x3045 || d === 0x3047 || d === 0x3049) {
        s.nucleus = idOf(['a', 'i', 'ɯ', 'e', 'o'][(d - 0x3041) / 2]);
        s.src += String.fromCodePoint(cps[i + 1]);
        i++;
      }
      if (geminate) { s.flags |= 2; geminate = false; }
      lastVowel = s.nucleus;
      out.push(s);
    }
    return out;
  }

  // ---- English: words through the CMU pronouncing dictionary (cmudict.js, first pronunciation of each word) ----
  let dict = null;
  function lookup(word) {
    if (typeof CMUDICT === 'undefined') return null;
    if (!dict) { dict = new Map(); for (const line of CMUDICT.split('\n')) { const sp = line.indexOf(' '); if (sp > 0) dict.set(line.slice(0, sp), line.slice(sp + 1)); } }
    return dict.get(word.toLowerCase()) ?? null;
  }

  // text -> { syllables, unknown }: words of kana, words in /slashes/ or [brackets] as IPA, other words as English
  function parse(text) {
    const syllables = [], unknown = [];
    for (const tok of text.split(/[\s、。，,]+/).filter(Boolean)) {
      if (/[ぁ-ゖァ-ヺー]/.test(tok)) { syllables.push(...parseKana(tok)); continue; }
      if (/^[\/\[].*[\/\]]$/.test(tok) || /[^\u0000-\u007F]/.test(tok)) { syllables.push(...parseIpa(tok)); continue; }
      const w = tok.replace(/[^A-Za-z']/g, '');
      if (!w) continue;
      const ph = lookup(w);
      if (ph) syllables.push(...parseArpabet(ph)); else unknown.push(w);
    }
    return { syllables, unknown };
  }

  const ipa = s => s.onset.map(i => PH[i][0]).join('') + (s.nucleus >= 0 ? PH[s.nucleus][0] : '') + (s.nucleus2 >= 0 ? PH[s.nucleus2][0] : '') + (s.flags & 1 ? 'ː' : '') + s.coda.map(i => PH[i][0]).join('');
  // the three numbers of a syllable (18 bits each, exact in a float32), as in shomyo.c
  function pack(s) {
    const f = a => a.reduce((x, id, k) => x + ((id + 1) << (6 * k)), 0);
    const A = f(s.onset), B = (s.nucleus + 1) | ((s.nucleus2 + 1) << 6) | ((s.flags & 63) << 12), C = f(s.coda);
    return [A / 262143, B / 262143, C / 262143];
  }
  return { parse, parseKana, parseIpa, parseArpabet, pack, ipa, idOf, PH };
})();
if (typeof module !== 'undefined') module.exports = Lyric;
