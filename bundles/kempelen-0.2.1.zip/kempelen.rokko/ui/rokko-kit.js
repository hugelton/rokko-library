// Rokko kit: the parts the example bundles share (rokko-kit.css has the look). Load it before the page's own script.
// Parts bound to a parameter id send one automation gesture per drag (rokko.begin / setParam / end) and follow the
// host: the kit keeps every value from rokko-init / rokko-param in Kit.values and updates the parts bound to that id,
// then the page's own listeners run.
const Kit = (() => {
  const values = new Map(), defaults = new Map(), bound = new Map();   // id -> value, id -> default, id -> [set]
  const clamp = v => Math.min(1, Math.max(0, v));
  const bind = (id, set) => { if (!bound.has(id)) bound.set(id, []); bound.get(id).push(set); if (values.has(id)) set(values.get(id)); };
  const watchers = [];   // fn(id, v) after any change, from the host or from the page
  const show = (id, v) => { values.set(id, v); for (const set of bound.get(id) || []) set(v); for (const fn of watchers) fn(id, v); };
  const watch = fn => watchers.push(fn);
  // a change made on the page: tell the host, update every part bound to the id
  const send = (id, v) => { v = clamp(v); show(id, v); rokko.setParam(id, v); };
  addEventListener('rokko-init', e => { for (const p of e.detail.params) { if (p.default !== undefined) defaults.set(p.id, p.default); show(p.id, p.value); } });
  addEventListener('rokko-param', e => show(e.detail.id, e.detail.value));

  // MIDI Learn: a right click on a part bound to a parameter asks Rokko to wait for the next CC (rokko.learn). The part
  // waiting is outlined until the CC comes or Escape cancels; rokko-learn says which one waits.
  const learnParts = new Map();   // id -> [el]
  let learning = null;
  function learnable(el, id) {
    if (id === undefined) return;
    if (!learnParts.has(id)) learnParts.set(id, []);
    learnParts.get(id).push(el);
    el.addEventListener('contextmenu', e => { e.preventDefault(); if (rokko.learn) rokko.learn(id); });
  }
  addEventListener('rokko-learn', e => {
    learning = e.detail.id ?? null;
    for (const [id, els] of learnParts) for (const el of els) el.classList.toggle('kit-learn', id === learning);
  });
  addEventListener('keydown', e => { if (e.key === 'Escape' && learning !== null && rokko.learn) rokko.learn(null); });

  // a drag on `el` that maps the pointer to a value with `at(e, start)`; one gesture per drag
  function drag(el, id, at) {
    let start = null;
    el.addEventListener('pointerdown', e => { if (e.button !== 0) return; el.setPointerCapture(e.pointerId); start = { x: e.clientX, y: e.clientY, v: values.get(id) ?? 0 }; rokko.begin(id); const v = at(e, start); if (v !== undefined) send(id, v); });
    el.addEventListener('pointermove', e => { if (!el.hasPointerCapture(e.pointerId)) return; const v = at(e, start); if (v !== undefined && v !== values.get(id)) send(id, v); });
    el.addEventListener('pointerup', e => { if (el.hasPointerCapture(e.pointerId)) el.releasePointerCapture(e.pointerId); rokko.end(id); });
    el.addEventListener('dblclick', () => { if (defaults.has(id)) { rokko.begin(id); send(id, defaults.get(id)); rokko.end(id); } });
  }
  const part = (cls, html) => { const el = document.createElement('div'); el.className = cls; el.innerHTML = html; return el; };
  const text = (el, sel, t) => { el.querySelector(sel).textContent = t; };

  // knob: o = { id, name, show(v) -> text, size (px, default 44), range (px of travel for 0..1, default 200) }
  function arc(v, r, c) {
    const a0 = -135, a = a0 + 270 * v, p = d => [c + r * Math.sin(d * Math.PI / 180), c - r * Math.cos(d * Math.PI / 180)];
    const [x0, y0] = p(a0), [x1, y1] = p(a);
    return `M${x0},${y0} A${r},${r} 0 ${a - a0 > 180 ? 1 : 0} 1 ${x1},${y1}`;
  }
  function knob(o) {
    const s = o.size || 44, c = s / 2, r = c - 4;
    const el = part('kit-knob', `<svg viewBox="0 0 ${s} ${s}" style="width:${s}px;height:${s}px"><path d="${arc(1, r, c)}" stroke="var(--line)" stroke-width="4" fill="none" stroke-linecap="round"/>` +
      '<path class="v" stroke="var(--accent)" stroke-width="4" fill="none" stroke-linecap="round"/></svg><div class="kit-value"></div><div class="kit-name"></div>');
    const k = { el, name(t) { text(el, '.kit-name', t); return k; } };
    drag(el, o.id, (e, s0) => s0.v + (s0.y - e.clientY) / (o.range || 200)); learnable(el, o.id);
    bind(o.id, v => { el.querySelector('.v').setAttribute('d', v > 0.001 ? arc(v, r, c) : ''); text(el, '.kit-value', (o.show || (x => x.toFixed(2)))(v)); });
    return k.name(o.name ?? '');
  }

  // vertical fader: o = { id, name, show, width }; f.mark(v or null) shows a second level beside the fill (e.g. CC11)
  function fader(o) {
    const el = part('kit-fader', '<div class="kit-value"></div><div class="kit-track"><div class="kit-fill"></div><div class="kit-mark"></div><div class="kit-cap"></div></div><div class="kit-name"></div>');
    if (o.width) el.style.width = o.width + 'px';
    const track = el.querySelector('.kit-track');
    drag(el, o.id, e => { const r = track.getBoundingClientRect(); return clamp((r.bottom - e.clientY) / r.height); }); learnable(el, o.id);
    bind(o.id, v => { el.querySelector('.kit-fill').style.height = v * 100 + '%'; el.querySelector('.kit-cap').style.bottom = v * 100 + '%'; text(el, '.kit-value', (o.show || (x => Math.round(x * 100)))(v)); });
    const f = { el, name(t) { text(el, '.kit-name', t); return f; },
      mark(v) { const m = el.querySelector('.kit-mark'); m.style.display = v === null ? 'none' : 'block'; if (v !== null) m.style.bottom = v * 100 + '%'; } };
    return f.name(o.name ?? '');
  }

  // horizontal slider row: o = { id, name, show }
  function slider(o) {
    const el = part('kit-slider', '<div class="kit-name"></div><div class="kit-track"><div class="kit-fill"></div><div class="kit-cap"></div></div><div class="kit-value"></div>');
    const track = el.querySelector('.kit-track');
    drag(track, o.id, e => { const r = track.getBoundingClientRect(); return clamp((e.clientX - r.left) / r.width); }); learnable(el, o.id);
    bind(o.id, v => { el.querySelector('.kit-fill').style.width = v * 100 + '%'; el.querySelector('.kit-cap').style.left = v * 100 + '%'; text(el, '.kit-value', (o.show || (x => Math.round(x * 100) + '%'))(v)); });
    const s = { el, name(t) { text(el, '.kit-name', t); return s; } };
    return s.name(o.name ?? '');
  }

  // segmented switch: o = { count, pick(i) } for a page-defined choice, or o = { id, count } for an enum parameter
  // (step i sent at the middle of its range, as the bundles' sr_param_spec "pick=bins" reads it)
  function seg(o) {
    const el = part('kit-seg', '');
    const buttons = [];
    for (let i = 0; i < o.count; i++) {
      const b = document.createElement('button');
      b.addEventListener('click', () => { if (o.pick) o.pick(i); else { rokko.begin(o.id); send(o.id, (i + 0.5) / o.count); rokko.end(o.id); } });
      el.appendChild(b); buttons.push(b);
    }
    const g = { el,
      labels(list) { buttons.forEach((b, i) => { b.textContent = list[i] ?? ''; }); return g; },
      set(i) { buttons.forEach((b, j) => b.classList.toggle('on', j === i)); return g; },
      enable(on) { el.classList.toggle('off', !on); return g; } };
    if (o.id !== undefined) { bind(o.id, v => g.set(Math.min(o.count - 1, Math.floor(v * o.count)))); learnable(el, o.id); }
    return g;
  }

  // toggle: o = { id } for an on/off parameter (on at >= 0.5), or o = { click() } for a page-defined action
  function toggle(o) {
    const el = document.createElement('button'); el.className = 'kit-toggle';
    const t = { el, label(s) { el.textContent = s; return t; }, set(on) { el.classList.toggle('on', !!on); return t; } };
    el.addEventListener('click', () => { if (o.click) o.click(); else { rokko.begin(o.id); send(o.id, (values.get(o.id) ?? 0) >= 0.5 ? 0 : 1); rokko.end(o.id); } });
    if (o.id !== undefined) { bind(o.id, v => { t.set(v >= 0.5); if (o.labels) el.textContent = o.labels()[v >= 0.5 ? 1 : 0]; }); learnable(el, o.id); }
    return t;
  }

  // keyboard: o = { first, last, marks: { note: text }, zone: [from, to], playable(n) -> bool,
  //                 press(n, velocity, from), release(n) }
  // Default press/release play the note into the plugin (from = the note a drag left, released first). Keys light up
  // for every note the plugin receives (rokko-note), the page's own included; `lit-2` is for a page's second colour.
  const isBlack = n => [1, 3, 6, 8, 10].includes(((n % 12) + 12) % 12);
  function keyboard(o) {
    const el = part('kit-keys', ''), keys = new Map(), whites = [];
    const press = o.press || ((n, vel, from) => { if (from !== undefined) rokko.noteOff(from); rokko.noteOn(n, vel); });
    const release = o.release || (n => rokko.noteOff(n));
    for (let n = o.first; n <= o.last; n++) if (!isBlack(n)) { const w = part('kit-white', ''); w.dataset.note = n; el.appendChild(w); whites.push(n); keys.set(n, w); }
    const wpc = 100 / whites.length;
    for (let n = o.first; n <= o.last; n++) if (isBlack(n)) {
      const b = part('kit-black', ''); b.dataset.note = n;
      b.style.left = `calc(${(whites.indexOf(n - 1) + 1) * wpc}% - ${wpc * 0.3}%)`; b.style.width = wpc * 0.6 + '%';
      el.appendChild(b); keys.set(n, b);
    }
    for (const [n, t] of Object.entries(o.marks || {})) { const k = keys.get(+n); if (k) k.appendChild(Object.assign(document.createElement('div'), { className: 'kit-mark', textContent: t })); }
    if (o.zone) for (let n = o.zone[0]; n <= o.zone[1]; n++) keys.get(n)?.classList.add('zone');
    const down = new Map();   // pointerId -> note
    const noteAt = e => { const t = document.elementFromPoint(e.clientX, e.clientY), k = t && t.closest('[data-note]'); return k && el.contains(k) ? +k.dataset.note : undefined; };
    const ok = n => n !== undefined && (!o.playable || o.playable(n));
    el.addEventListener('pointerdown', e => {
      el.setPointerCapture(e.pointerId);
      const n = noteAt(e); if (!ok(n)) return;
      const r = keys.get(n).getBoundingClientRect();   // lower on the key = louder
      down.set(e.pointerId, n); press(n, Math.round(60 + 67 * clamp((e.clientY - r.top) / r.height)));
    });
    el.addEventListener('pointermove', e => {
      if (!down.has(e.pointerId)) return;
      const n = noteAt(e), from = down.get(e.pointerId);
      if (ok(n) && n !== from) { down.set(e.pointerId, n); press(n, 100, from); }
    });
    for (const t of ['pointerup', 'pointercancel', 'lostpointercapture']) el.addEventListener(t, e => {
      const n = down.get(e.pointerId); if (n === undefined) return; down.delete(e.pointerId); release(n);
    });
    const kb = { el, keys,
      light(n, on, cls = 'lit') { keys.get(n)?.classList.toggle(cls, !!on); },
      clear(cls = 'lit') { for (const k of keys.values()) k.classList.remove(cls); },
      refresh() { for (const [n, k] of keys) k.classList.toggle('dead', !!o.playable && !o.playable(n)); } };
    if (o.follow !== false) addEventListener('rokko-note', e => kb.light(e.detail.note, e.detail.on));
    kb.refresh();
    return kb;
  }

  // The example pages are in English whatever the host's language. words = { en: {...} }
  function words(dict) {
    const w = { language: 'en', set() { document.documentElement.lang = 'en'; return w; },
      get: k => (dict[w.language] && dict[w.language][k]) ?? dict.en[k] ?? k };
    return w;
  }

  return { values, send, watch, learnable, knob, fader, slider, seg, toggle, keyboard, words, isBlack };
})();
